SkyTeam Crop & Print — starter website

HOW TO USE ON MOBILE
1. Download skyteam-website.zip and extract it with your phone's file manager.
2. Open index.html in a modern browser (Chrome recommended). If your browser blocks local file features, host the folder on a static hosting service.
3. Choose a tool, select a photo, generate the sheet, then Download PNG or Print / Save PDF.
4. PDF Print Tools opens a PDF saved on your device.

FEATURES
- English/Hindi UI
- ID, PVC-card-size, passport-photo, and WhatsApp-image print layouts
- A4 and 4x6 inch paper presets
- Browser-side image processing, PNG export, browser print dialog
- Local PDF preview/print attempt

LIMITATIONS
- This is a static front-end starter; it has no login, server, database, admin panel, cloud storage, payments, or live domain.
- It is not an official government service and cannot issue or alter government identity documents.
- Browser print scaling and margins vary by device. Select actual size / 100% in print settings and test with ordinary paper first.
- Use only documents and images you are authorized to process.
